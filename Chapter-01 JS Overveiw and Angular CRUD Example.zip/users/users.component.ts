import { Component } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {

  name:string='';   //default type is any 
  email:string=''; 
  salary:number=0; 
  users=[]
  eind = -1

  setName(event){
      this.name = event.target.value;
      //console.log(this.name);

  }
  setEmail(event){

    this.email = event.target.value;
    //console.log(this.email);
  }
  setSalary(event){

    this.salary = event.target.value;
    //console.log(this.salary);
  }

  addUser(){
      this.users.push({name:this.name,email:this.email,salary:this.salary});
      console.log(this.users);

        this.name='';
        this.email='';
        this.salary=0;


  }
  delRow(i){

    this.users.splice(i,1);

  }
  editRow(i){
      console.log("edit now");
    console.log(this.users[i]);

    this.name=this.users[i].name;
    this.email=this.users[i].email;
    this.salary=this.users[i].salary;
    //this.users.splice(i,1);

    this.eind = i
  }
  udpateUser(){

    this.users[this.eind].name = this.name;
    this.users[this.eind].email = this.email;
    this.users[this.eind].salary = this.salary;

  }
}

