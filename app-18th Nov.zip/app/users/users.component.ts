import { Component } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {

  name:string='';   //default type is any 
  email:string=''; 
  salary:number=0; 
  isusrChecked:boolean = false;
  users=[]
  eind = -1
  totalUsers:number = 0;
  markedUsers:number = 0;
  unmarkedUsers:number = 0;
  statusChk:boolean =false;
  setName(event){
      this.name = event.target.value;
      //console.log(this.name);

  }
  setEmail(event){

    this.email = event.target.value;
    //console.log(this.email);
  }
  setSalary(event){

    this.salary = event.target.value;
    //console.log(this.salary);
  }

  addUser(){
      this.users.push({name:this.name,email:this.email,salary:this.salary,marked:false});
      console.log(this.users);

        this.name='';
        this.email='';
        this.salary=0;
        this.markedUsers =this.users.filter (({marked}) => marked === true).length;
        this.unmarkedUsers =this.users.filter(item => item.marked == false).length;
      //  this.totalUsers =  this.totalUsers+1;
  }
  delRow(i){

    this.users.splice(i,1);

  }
  editRow(i){
      console.log("edit now");
    console.log(this.users[i]);

    this.name=this.users[i].name;
    this.email=this.users[i].email;
    this.salary=this.users[i].salary;
    //this.users.splice(i,1);

    this.eind = i
  }
  udpateUser(){

    this.users[this.eind].name = this.name;
    this.users[this.eind].email = this.email;
    this.users[this.eind].salary = this.salary;

  }
  chkMark(i){
    this.users[i].marked = !this.users[i].marked;
    this.markedUsers =this.users.filter (({marked}) => marked === true).length;
    this.unmarkedUsers =this.users.filter(item => item.marked == false).length;
  }
  delchkUser()
  {
    this.users = this.users.filter (x => x.marked === false);
    

  }
}

