import { Pipe, PipeTransform } from '@angular/core';
import { RouteReuseStrategy } from '@angular/router';

@Pipe({
  name: 'sorting'
})
export class SortingPipe implements PipeTransform {

  transform(data:any,mode):any {

    if(mode=='asc'){
      return data.sort();
    }else  if(mode=='desc'){
        return data.sort().reverse();
    }else{
        return data;
    }

    
  }

}
