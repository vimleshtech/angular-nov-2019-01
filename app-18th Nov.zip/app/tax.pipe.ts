import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tax'
})
export class TaxPipe implements PipeTransform {

  transform(value: number, country:string, cat:string): any {

    var tax=0;
    if(country=='india' && cat=='food'){
      tax =value*.05;
    }else if(country=='india' && cat=='electric'){
      tax =value*.18;
    }else if(country=='india' && cat=='cloth'){
      tax =value*.12;
    }else if(country=='india' && cat=='auto'){
      tax =value*.18;
    }
    else if(country=='us' && cat=='cloth'){
     tax =value*.30;
    }


    return tax;
  }

}
