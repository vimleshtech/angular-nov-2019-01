import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BodyComponent } from './body/body.component';
import { UsersComponent } from './users/users.component';
import { SheaderComponent } from './sheader/sheader.component';
import { SfooterComponent } from './sfooter/sfooter.component';
import { ChildComponent } from './child/child.component';
import { SortingPipe } from './sorting.pipe';
import { TaxPipe } from './tax.pipe';
import { CuststyleDirective } from './custstyle.directive';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    UsersComponent,
    SheaderComponent,
    SfooterComponent,
    ChildComponent,
    SortingPipe,
    TaxPipe,
    CuststyleDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
