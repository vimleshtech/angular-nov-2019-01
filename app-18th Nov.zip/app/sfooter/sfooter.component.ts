import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sfooter',
  templateUrl: './sfooter.component.html',
  styleUrls: ['./sfooter.component.css']
})
export class SfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
