import { CuststyleDirective } from './custstyle.directive';

describe('CuststyleDirective', () => {
  it('should create an instance', () => {
    const directive = new CuststyleDirective();
    expect(directive).toBeTruthy();
  });
});
