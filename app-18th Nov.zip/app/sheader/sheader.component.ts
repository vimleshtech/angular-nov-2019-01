import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sheader',
  templateUrl: './sheader.component.html',
  styleUrls: ['./sheader.component.css']
})
export class SheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
