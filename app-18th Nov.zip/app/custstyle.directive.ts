import { Directive,ElementRef,Input } from '@angular/core';

@Directive({
  selector: '[appCuststyle]'
})
export class CuststyleDirective {

  @Input() name:string 
  @Input()  value:string

  constructor(ele:ElementRef) {

    console.log(this.value);

    //if (this.var =='true'){

    
    ele.nativeElement.style.backgroundColor="red";
    ele.nativeElement.style.color="blue";
  //}

    //ele.nativeElement.innerHTML="<input type='text' />"

   }

}
