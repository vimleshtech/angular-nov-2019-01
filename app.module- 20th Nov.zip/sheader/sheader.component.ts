import { Component, OnInit } from '@angular/core';
import { stringify } from '@angular/compiler/src/util';
import { UtilsService } from 'src/app/utils.service';

@Component({
  selector: 'app-sheader',
  templateUrl: './sheader.component.html',
  styleUrls: ['./sheader.component.css']
})
export class SheaderComponent implements OnInit {

  name:string
  email 
  phone 
  item=[]
  constructor(private obj:UtilsService) { }

  getData(){

    var o = this.obj.GST(123345);
    console.log(o);
    
    var o = this.obj.sal(34000);
    console.log(o);
    

  }
  setName(event){

    this.name = event.target.value;

  }
  saveToLocal(){
    console.log(this.email);

    this.item.push({name:this.name,email:this.email,phone:this.phone});

    localStorage.setItem("data",JSON.stringify(this.item));

    

  }
  ngOnInit() {
  }

}
