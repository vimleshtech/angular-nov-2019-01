import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {



  constructor() { }

  GST(amt:number):number{

    var t=0;
    if(amt>1000){
        t = amt*.18;
    }
    else if(amt>5000){
      t = amt*.10;
    } 
   else  if(amt>100){
      t = amt*.05;
    }

    return t;
  }

  sal(basic:number){

    var hra = basic*.40;
    var da = basic*.20;
    var msal  = hra+da+basic;
    var ysal = msal *12;
    return ysal;

  }
}
