import { Component, OnInit } from '@angular/core';
import { parse } from 'querystring';

@Component({
  selector: 'app-sfooter',
  templateUrl: './sfooter.component.html',
  styleUrls: ['./sfooter.component.css']
})
export class SfooterComponent implements OnInit {

  data =[]
  constructor() { }

  readLocal(){
    this.data = JSON.parse(localStorage.getItem("data"));
    console.log(this.data);
  }
  ngOnInit() {
  }

}
